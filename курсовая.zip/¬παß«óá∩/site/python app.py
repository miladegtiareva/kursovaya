from flask import Flask, request, render_template
import logging
import pickle
import pandas as pd
import numpy as np

# Создание Flask приложения
app = Flask(__name__)

# Конфигурация для логирования ошибок на уровне ERROR
logging.basicConfig(level=logging.ERROR)

# Попытка загрузить модель и дополнительные компоненты (энкодеры и скейлеры) с обработкой возможных ошибок
try:
    # Загрузка предварительно обученной модели (например, случайного леса)
    with open('random_forest_model.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    
    # Загрузка энкодеров для категориальных переменных
    with open('label_encoders.pkl', 'rb') as encoders_file:
        label_encoders = pickle.load(encoders_file)
    
    # Загрузка скейлера для нормализации предсказаний
    with open('scaler.pkl', 'rb') as scaler_file:
        scaler = pickle.load(scaler_file)
except Exception as e:
    # Логирование ошибки, если не удалось загрузить компоненты
    app.logger.error(f"Ошибка загрузки модели или компонентов: {e}")

# Определение главного маршрута (главной страницы)
@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None  # Переменная для хранения результата предсказания
    form_data = {
        'PROJECT_NAME': '',
        'ISSUE_PRIORITY': '',
        'ISSUE_TYPE': ''
    }  # Словарь для хранения данных формы

    # Если метод запроса POST (данные отправлены через форму)
    if request.method == 'POST':
        try:
            # Получение данных из формы и конвертация в словарь
            data = request.form.to_dict(flat=True)
            form_data.update(data)  # Обновление form_data с введенными данными

            print(f"Полученные данные из формы: {data}")
            # Преобразование данных формы в DataFrame для работы с моделью
            df = pd.DataFrame([data])

            # Использование энкодеров для преобразования категориальных данных
            for column, le in label_encoders.items():
                if column in df.columns:
                    df[column] = le.transform(df[column])

            print(f"Преобразованные данные для предсказания: {df}")

            # Выполнение предсказания на обученной модели
            pred_log = model.predict(df)
            pred_normalized = scaler.inverse_transform(pred_log.reshape(-1, 1))

            # Извлечение и округление результата предсказания
            prediction = round(pred_normalized[0][0])
            print(f"Предсказанное значение: {prediction}")

        except Exception as e:
            # Логирование любой ошибки, возникшей в процессе обработки данных
            app.logger.error(f"Ошибка в процессе обработки: {e}")
            return render_template('error.html'), 400  # Возврат страницы ошибки

    # Отображение основного шаблона с предсказанием и переданными данными формы
    return render_template('index.html', prediction=prediction, form_data=form_data)

# Запуск приложения
if __name__ == '__main__':
    app.run(debug=True)